
Page({
  
  data: {
    imgSrc:'/images/1.jpg', 
    imgSrc1:'/images/2.jpg',
   
    autoplay: true,
    interval: 3000,
    duration: 1200
  },
  onLoad: function () {
    var that = this; 
    this.videoCtx=wx.createVideoContext('myvideo')
    var data = {
      "datas": [
        {
          "id": 1,
          "imgurl": "../../images/a1.jpg"
        },
        {
          "id": 2,
          "imgurl": "../../images/a2.jpg"
        },
        {
          "id": 3,
          "imgurl": "../../images/a3.jpg"
        }
      ]
    }; 
    that.setData({
      lunboData: data.datas
    })
  },
  start(){
    wx.navigateTo({
      url: '/pages/game/game'
    })
  },
  inputblur(e){
    this.inputValue=e.detail.value
},
  a1(){
    wx.navigateTo({
      url: '/pages/denglu/denglu',
    })
  },
  a2(){
    wx.navigateTo({
      url: '/pages/guanyu/guanyu',
    })
  }
  
    
})