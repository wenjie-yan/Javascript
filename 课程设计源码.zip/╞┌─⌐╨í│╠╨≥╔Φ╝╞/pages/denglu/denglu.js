// pages/denglu/denglu.js
Page({

    data: {
        name:'',
        pwd:'',
        confirm:'',
        count:'',
        country:["CHN","JPN","FRA","GBR","USA","RSA"]
    },

    formsubmit(e){
        if(e.detail.value.name.length==0  ||  e.detail.value.passward.length==0){
            this.setData({
                showmsg01:'用户名或密码不得为空！',
            })
        }
        else if(e.detail.value.passward != e.detail.value.confirm){
            this.setData({
                showmsg02:'两次密码输入不一致！',
                pwd:'',
                confirm:''
            })
        }
        else{
            wx.showToast({
                title: '登陆成功',
                icon:'loading'
              })
            wx.navigateBack({
              delta: 0,
            })
            wx.setStorageSync('用户名',[ e.detail.value.name,this.data.count])
        }
    },
    inputname(e){
        var email=e.detail.value;
        var check=this.check(email);
    },
    check(e){
        let str=/^[a-zA-Z-]$/
        if(str.test(e)){
            return true;
        }
        else{
            
            this.setData({
                getmail:''
            })
            return false;
        }
    },
    pickercountry(e){
         this.count=this.data.country[e.detail.value];
         this.setData({
               count:this.count
         })
        
    }
})