Page({
    data: {
        score:0,//我的得分
        startx:0,//触摸开始的横坐标
        starty:0,//触摸开始的纵坐标
        endx:0,//触摸结束的横坐标
        endy:0,//触摸结束的纵坐标
        area:[],//我的游戏区域
        rows:28,//行数
        cols:22,//列数
        name:['游客','未知'],//用户名
        snake:[],//蛇
        food:[],//食物
        direction:"",//移动方向
        timer:"",//初始化定时器
        grade:[]
    },
    onShow: function () {
        var name=wx.getStorageSync('用户名');
        if(name.length>0){
            f=1;
            this.setData({
                name:name
            })
        }
        else{
            f=0;
            this.setData({
                name:['游客','未知']
            })
        }
    },
    onLoad:function(e){
        this.initarea(this.data.rows,this.data.cols)//函数调用初始化区域
        this.initsnake(3)
        this.createfood()
        this.move()
        
        
    },
    //初始我的游戏区域/把行数和列数改写成二维数组
    initarea(rows,cols){
        for(var i=0;i<rows;i++){
            var arr=[];
            this.data.area.push(arr);
            for(var j=0;j<cols;j++){
                this.data.area[i].push(0)
            }
        }
    },
    //初始化蛇,蛇的长度是len,宽度是1
    initsnake(len){
        for(var i=0;i<len;i++){
            this.data.area[0][i]=1
            this.data.snake.push([0,i])
        }
    },
    //创建食物
    createfood(){
        var x=Math.floor(Math.random()*this.data.rows)
        var y=Math.floor(Math.random()*this.data.cols)
        var area=this.data.area
        area[x][y]=2
        var snake=this.data.snake;
        for(var i=0;i<snake.length;i++){
            var node=snake[i][1];
            //判断食物和蛇一开始是否重合，蛇为[0,0][0,1][0,2]
            if(x==0 && y==node){
                createfood()
                return
            }else{
                this.setData({
                    area:area,
                    food:[x,y]
                })
            }
        }
    },
    //手指触摸开始游戏
    touchstart(e){
        this.setData({
            startx:e.touches[0].pageX,
            starty:e.touches[0].pageY
        })
    },
    //手指触摸移动
    touchmove(e){
        this.setData({
            endx:e.touches[0].pageX,
            endy:e.touches[0].pageY
        })
    },
    //手指触摸结束
    touchend(e){
        //获取滑动距离（横纵坐标之差)这里我用了三目运算符判断endx,endy是否为负
        var heng=(this.data.endx)?(this.data.endx-this.data.startx):0
        var zong=(this.data.endy)?(this.data.endy-this.data.starty):0
        var direction
        //判断滑动方向
        if(Math.abs(heng)>Math.abs(zong) &&heng>0){
            console.log("向右滑动")
            direction="right"
        }else if(Math.abs(heng)>Math.abs(zong) &&heng<0){
            console.log("向左滑动")
            direction="left"
        }else if(Math.abs(heng)<Math.abs(zong) &&zong>0){
            console.log("向下滑动")
            direction="down"
        }else if(Math.abs(heng)<Math.abs(zong) &&zong<0){
            console.log("向上滑动")
            direction="up"
        }else{
            console.log("点击会滑动")
        }
       this.setData({
           direction:direction,
           startx:0,
           starty:0,
           endx:0,
           endy:0
           //因为获取一次之后要重新赋回0
       })
    },
    //移动定时器
    move(){
        var that=this;
        this.data.timer=setInterval(function(){
            that.changedirection(that.data.direction)
            that.setData({
                area:that.data.area
            })
        },400)
    },
     //改变方向
     changedirection(direction){
        switch(direction){
            case "left":return this.changeleft();
                break;
            case "right":return this.changeright();
                break;
            case "up":return this.changeup();
                break;
            case "down":return this.changedown();
                break;
        }
    },
    //检查蛇头是否碰壁或者吃到自己
    checkgame(snaketail){
        var arr=this.data.snake;
        var len=this.data.snake.length;
        var snakeHead=arr[len-1];
        if(snakeHead[0]<0 ||snakeHead[0]>=this.data.rows||snakeHead[1]<0 ||snakeHead[1]>=this.data.cols){
            clearInterval(this.data.timer)//当小蛇超过地图范围那么就会清空定时器
            var that=this;
            this.data.grade.push([this.data.name,this.data.score])//添加成绩
            wx.setStorageSync('成绩', this.data.grade)
            wx.showModal({//结束之后蹦出的提示框
                title: '游戏结束',
                content: '您已碰壁，是否重新开始',
                success (res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                    that.setData({
                        score:0,
                        area:[],
                        snake:[],
                        food:[],
                        direction:""
                    })
                    that.onLoad()
                  } else if (res.cancel) {
                    console.log('用户点击取消')
                  }
                }
              })
              
        };
        for(var i=0;i<len-1;i++){//遍历蛇身
            if(snakeHead[0]==arr[i][0] &&snakeHead[1]==arr[i][1]){
                clearInterval(this.data.timer)//蛇头撞到了自己
                var that=this;
                this.data.grade.push([this.data.name,this.data.score])//添加成绩
                wx.setStorageSync('成绩', that.data.grade)
                wx.showModal({//结束之后蹦出的提示框
                    title: '游戏结束',
                    content: '您已吃到自己，是否重新开始',
                    success (res) {
                      if (res.confirm) {
                        console.log('用户点击确定')
                        that.setData({
                            score:0,
                            area:[],
                            snake:[],
                            food:[],
                            direction:""
                        })
                        that.onLoad()
                      } else if (res.cancel) {
                        console.log('用户点击取消')
                      }
                    }
                  })
            }
        }
        //吃到食物的触发
        if(snakeHead[0]==this.data.food[0] &&  snakeHead[1]==this.data.food[1]){
            arr.unshift(snaketail)
            this.setData({
                score:this.data.score+1
            })
            this.createfood()
        }
    },
    //不同方向的坐标变化
    changeleft(){
        var arr=this.data.snake;
        var len=this.data.snake.length;
        var snakehead=arr[len-1][1];
        var snaketail=arr[0];
        var area=this.data.area;
        area[snaketail[0]][snaketail[1]]=0
        for(var i=0;i<len-1;i++){
            arr[i]=arr[i+1]
        }
        var x=arr[len-1][0]
        var y=arr[len-1][1]-1
        arr[len-1]=[x,y]
        this.checkgame(snaketail)
        for(var i=0;i<len-1;i++){
            area[arr[i+1][0]][arr[i+1][1]]=1
        }
        this.setData({
            area:area,
            snake:arr
        })
        return true
    },
    changeright(){
        var arr=this.data.snake;
        var len=this.data.snake.length;
        var snakehead=arr[len-1][1];
        var snaketail=arr[0]
        var area=this.data.area;
        area[snaketail[0]][snaketail[1]]=0
        for(var i=0;i<len-1;i++){
            arr[i]=arr[i+1]
        }
        var x=arr[len-1][0]
        var y=arr[len-1][1]+1
        arr[len-1]=[x,y]
        this.checkgame(snaketail)
        for(var i=0;i<len-1;i++){
            area[arr[i+1][0]][arr[i+1][1]]=1
        }
        this.setData({
            area:area,
            snake:arr
        })
        return true
    },
    changeup(){
        var arr=this.data.snake;
        var len=this.data.snake.length;
        var snakehead=arr[len-1][1];
        var snaketail=arr[0]
        var area=this.data.area;
        area[snaketail[0]][snaketail[1]]=0
        for(var i=0;i<len-1;i++){
            arr[i]=arr[i+1]
        }
        var x=arr[len-1][0]-1
        var y=arr[len-1][1]
        arr[len-1]=[x,y]
        this.checkgame(snaketail)
        for(var i=0;i<len-1;i++){
            area[arr[i+1][0]][arr[i+1][1]]=1
        }
        this.setData({
            area:area,
            snake:arr
        })
        return true
    },
    changedown(){
        var arr=this.data.snake;
        var len=this.data.snake.length;
        var snakehead=arr[len-1][1];
        var snaketail=arr[0]
        var area=this.data.area;
        area[snaketail[0]][snaketail[1]]=0
        for(var i=0;i<len-1;i++){
            arr[i]=arr[i+1]
        }
        var x=arr[len-1][0]+1
        var y=arr[len-1][1]
        arr[len-1]=[x,y]
        this.checkgame(snaketail)
        for(var i=0;i<len-1;i++){
            area[arr[i+1][0]][arr[i+1][1]]=1
        }
        this.setData({
            area:area,
            snake:arr
        })
        return true
    },
    
})