Page({
    data: {
        grade:[]
    },

    onShow: function (options) {
        this.data.grade=wx.getStorageSync('成绩')
        //给grade数组排个序
        var grade=this.data.grade;
        var len=grade.length;
        for(var i=0; i<len-1; i++){
            for(var j=0; j<len-i-1; j++){
                if(grade[j][1] < grade[j+1][1]){
                    var temp = grade[j];
                    grade[j] = grade[j+1];
                    grade[j+1] = temp;
                }
            }
        }
        this.setData({
            grade:grade
        })
        
    },
    clear(){
        wx.removeStorageSync('成绩')
        this.setData({
            grade:[]
        })
    }

})