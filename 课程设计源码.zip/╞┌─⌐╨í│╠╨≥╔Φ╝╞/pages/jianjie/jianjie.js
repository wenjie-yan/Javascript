// pages/jianjie/jianjie.js
Page({

    /**
     * 页面的初始数据
     */
    data: {

    },
    
    onLoad: function (options) {
      this.videoCtx=wx.createVideoContext('myvideo')
      },
      inputblur(e){
          this.inputValue=e.detail.value
      }
})