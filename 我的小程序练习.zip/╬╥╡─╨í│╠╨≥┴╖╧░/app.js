// app.js
App({
  globalmsg:'我是来自APP.js的全局变量',
  globalfunc(){
    return '我是来自app.js的全局函数'
  },
  onLaunch() {
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
  },
  globalData: {
    userInfo: null
  },
  onLaunch(){
    console.log('app.js--onlaunch--小程序初始化')
  },
  onShow(){
    console.log('app.js--onshow--小程序显示')
  },
  onHide(){
    console.log('app.js==onhide--小程序隐藏')
  }
})
