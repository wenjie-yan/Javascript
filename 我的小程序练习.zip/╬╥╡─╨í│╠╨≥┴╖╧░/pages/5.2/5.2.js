Page({
    getinput(e){
        this.inputval=e.detail.value
    },
    onShow: function () {
        var that=this;
        that.isshow=true;
        wx.onAccelerometerChange(function(e) {
            if(!that.isshow){
                return
            }
            if(e.x>0.5  ||  e.y>0.5  ||e.z>0.5){
                wx.showToast({
                  title: '摇一摇成功',
                  icon:'success',
                  duration:2000
                })
                var result=1;
                for(var i=i;i<=that.inputval;i++){
                    result=result*i;
                }
                that.setData({
                    result:result
                })
            }
        })
    },
    onHide: function () {
        this.isshow=flase;
    }
})