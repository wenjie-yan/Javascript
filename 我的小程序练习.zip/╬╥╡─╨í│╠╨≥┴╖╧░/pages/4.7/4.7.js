
Page({

    /**
     * 页面的初始数据
     */
    data: {
        src:'../../images/OIP-C.jpg',
        imgarray:[{
            mode:'aspectFit',
            text:'aspectfit:保持纵横比例缩放，完整显示'
        },{
            mode:'scaleToFill',
            text:'scaleToFill:适当拉伸'
        },{
            mode:'aspectFill',
            text:'aspectFill:短边完全显示'
        },{
            mode:'top',
            text:'top:只显示顶部区域'
        },{
            mode:'bottom',
            text:'bottom:只显示底部区域'
        },{
            mode:'center',
            text:'v=center:只显示中间区域'
        },{
            mode:'left',
            text:'left:只显示左部区域'
        },{
            mode:'right',
            text:'right:只显示右部区域'
        },{
            mode:'top left',
            text:'top left:只显示左上部区域'
        }
    
    
    
    ]
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})