
Page({
    data: {
        mySize:'25px'
    },

   checkChange:function(e){
       var text=[];
       var mybold='';
       var myitalic='';
       var myunderline=''
       text=e.detail.value;
       for(var i=0;i<text.length;i++){
            if(text[i]=='isBold'){
               mybold='bold';
            }
            if(text[i]=='isItalic'){
            myitalic='italic';
            }
            if(text[i]=='isUnderline'){
            myunderline='underline';
            }
       }
       this.setData({
           myBold:mybold,
           myItalic:myitalic,
           myUnderline:myunderline
       })
       console.log(text[0],text[1],text[2])
   },
   radioChange(e){
       this.setData({
           mySize:e.detail.value,
       })
       console.log(e.detail.value);
   }
})