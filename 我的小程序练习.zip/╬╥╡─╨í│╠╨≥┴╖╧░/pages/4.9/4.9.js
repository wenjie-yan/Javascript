function getRandomColor(){
    let rgb=[]
    for(let i=0;i<3;++i){
        let color =Math.floor(Math.random()*256).toString(16)
        color=color.length==1?'0'+color:color
        rgb.push(color)
    }
    return '#'+rgb.join('')
}
Page({
    data: {
        danmulist:[{
            text:'第一秒出现的弹幕',
            color:'#ff0000',
            time:1
        },{
            text:'第三秒出现的弹幕',
            color:'#ff00ff',
            time:3
        }
    ]
    },
    onLoad: function (options) {
    this.videoCtx=wx.createVideoContext('myvideo')
    },
    inputblur(e){
        this.inputValue=e.detail.value
    },
    senddanmu(){
        this.videoCtx.senddanmu({
            text:this.inputvalue,
            color:getRandomColor()
        })
    }
})