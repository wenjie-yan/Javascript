// index.js
// 获取应用实例
const app = getApp()

Page({//31.315864,121.393443
  data: {
    latitude:31.315864,
    longitude:121.393443,
    markers:[
      {//31.316688,121.392134
        id:1,
        latitude:31.316688,
        longitude:121.392134,
        iconPath:'/images/cat01.jpg',
        label:{
          content:'my location',
          color:'#0000FF',
          bgcolor:'#FFFF00',
          fontsize:'20'
        }
      },
      {//31.314887,121.394872
        id:2,
        latitude:31.314887,
        longitude:121.394872,
        iconPath:'/images/bdd.jpg',
        label:{
          content:'class location',
          color:'#0000FF',
          bgcolor:'#FFFF00',
          fontsize:'20'
        }
      }
    ]
  },
  chooselocation(){
    wx.chooseLocation({
      success(res){
        console.log(res)
      }
    })
  },
  openlocation(){
    wx.openLocation({
      type:'gcj02',
      success(res){
        wx.openLocation({
          latitude: res.latitude,
          longitude: res.longitude,
        })
      }
    })
  }
  
})
