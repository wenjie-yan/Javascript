var rand,sum;
function creatrand(){
  rand=[];
  sum=0;
  for(var i=0;i<6;i++)
  {
    var r=(Math.random()*100).toFixed(2)*1;
    rand.push(r);
    sum +=r;
    console.log(rand[i]);
    sum=sum.toFixed(2)*1;
  }
  console.log(sum);
};
Page({
  data: {

  },
  onLoad: function (options) {
    creatrand();
    this.setData({
      rand:rand,
      sum:sum
    })
  },
  newrand:function(){
    creatrand();
    this.setData({
      rand:rand,
      sum:sum
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})