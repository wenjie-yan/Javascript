// pages/2.13/2.13.js
var num=60,timeID;
Page({
  data: {
    hidden:true,
    btn:false,
    btnn:true,
    num:num
  },
onLoad: function (options) {
var that=this;
setTimeout(() => {
  that.show()
}, 1000);
  },
show:function(){
    var that=this;
    that.setData({
      hidden:false
    })
  },
start:function(){
  var that=this;
  that.setData({
    btn:true,
    btnn:false
  })
  timeID=setInterval(()=>{
    that.timer()},1000)
},
end:function(){
  clearInterval(timeID)
  this.setData({
    btn:false,
    btnn:true
  })
},
timer:function(){
  var that=this;
  console.log(num)
  if(num>0){
    that.setData({
      num:num--
    })
  }
  else{
    that.setData({
      num:0
    })
  }
  console.log(num)
}
})