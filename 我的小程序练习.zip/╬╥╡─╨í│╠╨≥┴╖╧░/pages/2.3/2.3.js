Page({

   
    data: {
        imgsrc:'/images/shu.jpg'
    },
    tapcat:function(){
        let audio=wx.createInnerAudioContext()
        audio.src='/audios/meow.mp3'
        audio.play()
      },
      bindname(){
        wx.navigateTo({
        url: '../production/news'
        })
      },
    
})