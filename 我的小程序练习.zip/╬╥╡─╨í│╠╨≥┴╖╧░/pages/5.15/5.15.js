Page({
    name:'',
    phone:'',
    scancode(){
        var that=this;
        wx.scanCode({
          onlyFromCamera: false,
          scanType:[],
          success(res){
              that.setData({
                  resCode:res
              })
          }
        })
    },
    inputname(e){
        this.name=e.detail.value;
    },
    inputphone(e){
        this.phone=e.detail.value;
    },
    makecall(){
        let phone=this.phone;
        wx.makePhoneCall({
          phoneNumber: 'phone',
        })
    },
    addperson(){
        let name=this.name;
        let phone=this.phone;
        if(name=='' ||  phone==''){
            wx.showToast({
              title: '姓名和电话不能为空',
            })
        }else{
            wx.addPhoneContact({
                firstName:name,
                mobilePhoneNumber:phone
            })
        }
    }
})