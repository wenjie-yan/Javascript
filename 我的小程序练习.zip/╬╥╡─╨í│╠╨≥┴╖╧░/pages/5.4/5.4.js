// pages/5.4/5.4.js
Page({

    /**
     * 页面的初始数据
     */
    data: {

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        this.ctx=wx.createCanvasContext('mycanvas',this);
    },
    drawcircle(e){
        var x=e.detail.value.x;
        var y=e.detail.value.y;
        var radius=e.detail.value.radius;
        this.ctx.arc(x,y,radius,0,2*Math.PI);
        this.ctx.stroke();
        this.ctx.draw(true);
    },
    clear(){
        this.ctx.draw();
    }
})