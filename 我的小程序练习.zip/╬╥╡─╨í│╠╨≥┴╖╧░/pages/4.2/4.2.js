
Page({

   
    data: {
        a:'',
        b:'',
        c:'',
        result:''
    },
    submit:function(e){
        var a=parseInt(e.detail.value.a);
        var b=parseInt(e.detail.value.b);
        var c=parseInt(e.detail.value.c);
        var area;
        if(a+b<=c || b+c<=a || a+c<=b){
            wx.showToast({
              title: '三角形的两边之长小于第三边，不符合规则',
              icon:'none',
              duration:2000,
            });
            return;
        }
        else{
            var s=(a+b+c)/2;
            area=Math.sqrt(s*(s-a)*(s-b)*(s-c))
        }
        this.setData({
            result:area
        })
    }

})