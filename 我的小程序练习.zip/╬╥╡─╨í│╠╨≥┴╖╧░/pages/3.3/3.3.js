// pages/3.3/3.3.js
Page({

   
    data: {
        a:10,
        b:20,
        c:30,
        student:{
            stuID:'21121947',
            name:'闫文杰',
            birthday:'20030208'
        },
        array:[
            '2018','2019','2020'
        ]
    },
    modify(){
this.setData({
    a:100,
    b:200,
    c:300,
    student:{
        stuID:'000000',
        name:'张三',
        birthday:'20002020'
    },
    array:[
        '1','2','3'
    ]
})
    },
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})