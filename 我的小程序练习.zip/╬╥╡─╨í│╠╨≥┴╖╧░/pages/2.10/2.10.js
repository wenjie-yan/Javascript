Page({

    data: {
        flag:true,
        name:'',
        chinese_score:'',
        math_score:'',
        english_score:'',
        avrage:''
    },
    nameinput:function(e){
        var name1;
        name1=e.detail.value;
        this.setData({
            name:name1
        })
    },
    chineseinput:function(e){
        var chinese;
        chinese=e.detail.value;
        this.setData({
            chinese_score:chinese
        })
    },
    mathinput:function(e){
        var math;
        math=e.detail.value;
        this.setData({
            math_score:math
        })
    },
    englishinput:function(e){
        var english;
        english=e.detail.value;
        this.setData({
            english_score:english
        })
    },
    mysubmit:function(){
        if(this.data.name_score==''||this.data.chinese_score==''||this.data.math_score==''||this.data.english_score=='')
        return;
        else{
            var avg=(this.data.chinese_score*1+this.data.math_score*1+this.data.english_score*1)/3;
            this.setData({
                avrage:avg,
                flag:false 
            })
        }
    }
})













  