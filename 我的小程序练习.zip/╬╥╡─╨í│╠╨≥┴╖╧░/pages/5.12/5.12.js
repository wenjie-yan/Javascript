Page({
    data: {
        hidden:true,
        msg:''
    },
    student(id,name,chinese,math,english){
        this.id=id;
        this.name=name;
        this.chinese=chinese;
        this.math=math;
        this.english=english;
    },
    loadstudent(){
        var students=new Array();
        var stu1=new this.student('1','tom',95 ,87,78);
        var stu2=new this.student('1','tom',95 ,87,78);
        students.push(stu1);
        students.push(stu2);
        return students
    },
    a1(){
        var that=this
        wx.setStorage({
            key:'高一',
            data:this.loadstudent(),
            success(){
                that.setData({
                    hidden:false,
                    msg:'异步存储数据成功！'
                })
            }
        })
    },
    a2(){
        var that=this;
        wx.getStorage({
            key:'高一',
            success(res){
                var length=res.data.length;
                if(length>1){
                    that.setData({
                        hidden:false,
                        msg:'异步读取数据成功！'
                    })
                    console.log(res.data)
                }
            },
            fail(){
                that.setData({
                    hidden:false,
                    msg:'异步获取缓存失败！'
                })
            }
        })
    },
    a3(){
        var that=this;
        wx.getStorageInfo({
          success: (option) => {
              that.setData({
                  hidden:false,
                  msg:'异步获取缓存信息成功!'
              })
              console.log(option)
          },
          fail(){
              that.setData({
                  hidden:false,
                  msg:'异步获取缓存信息失败！'
              })
          }
        })
    },
    a4(){
        var that=this;
        wx.removeStorage({
            key:'高一',
            success(res){
                that.setData({
                    hidden:false,
                    msg:'异步删除数据成功!'
                })
            }
        })
    },
    b1(){
        var that=this
        wx.setStorageSync('高二', this.loadstudent())
        that.setData({
           hidden:false,
           msg:'同步存储数据成功！'
        })
    },
    b2(){
        var that=this;
        try{
            var value=wx.getStorageSync('高二');
            var length=value.length;
            if(length>1){
                that.setData({
                    hidden:false,
                    msg:'同步获取缓存数据成功!'
                })
                console.log(value)
            }
        }catch(e){
            that.setData({
                hidden:false,
                msg:'同步获取缓存数据失败！'
            })
            console.log(e);
        }
    },
    b3(){
        var that=this;
        try{
            var res=wx.getStorageInfoSync()
            that.setData({
                hidden:false,
                msg:'同步获取存储信息成功!'
            })
            console.log(res)
        }catch(e){
            that.setData({
                hidden:false,
                msg:'同步获取缓存信息失败！'
            })
            console.log(e)
        }
    },
    b4(){
        var that=this;
        try{
            wx.removeStorageSync('高二');
            that.setData({
                hidden:false,
                msg:'同步删除数据成功！'
            })
        }catch(e){
            that.setData({
                hidden:false,
                msg:'同步删除数据失败！'
            })
        }
    }
})