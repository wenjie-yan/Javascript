// pages/4.4/4.4.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        r:50,
        g:100,
        b:150,
        a:1
    },

    colorchange(e){
        let color=e.currentTarget.dataset.color
        let value=e.detail.value;
        console.log(color,value)
        this.setData({
            [color]:value
        })
    }
})