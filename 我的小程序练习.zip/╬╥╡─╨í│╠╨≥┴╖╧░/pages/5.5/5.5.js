Page({
    onReady: function () {
        this.ctx=wx.createCanvasContext('mycanvas', this);
    },
    drawrect(){
        var ctx=this.ctx;
        ctx.rect(0,0,50,50)
        ctx.stroke()
        ctx.draw(true)
    },
    scale(){
        this.ctx.scale(2,2)
        this.drawrect()
    },
    rotate(){
        this.ctx.rotate(30*Math.PI/180)
        this.drawrect()
    }
  
})