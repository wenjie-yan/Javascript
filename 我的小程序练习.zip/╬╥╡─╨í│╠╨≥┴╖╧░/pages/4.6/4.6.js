function person(name,sex,birthplace,birthday,height,weight)
{
    this.name=name;
    this.sex=sex;
    this.birthplace=birthplace;
    this.birthday=birthday;
    this.height=height;
    this.weight=weight;
}
Page({

    /**
     * 页面的初始数据
     */
    data: {
        flag:true,
        gender:["男","女"]
    },

   nameinput(e){
       this.name=e.detail.value;
   },
   picksex(e){
       this.sex=this.data.gender[e.detail.value];
       this.setData({
           sex:this.sex
       })
   },
   pickregion(e){
    this.birthplace=e.detail.value;
    this.setData({
        birthplace:this.birthplace
    })
    },
    pickerdate(e){
        this.birthday=e.detail.value;
        this.setData({
            birthday:this.birthday
        })
        },
    heightinput(e){
         this.height=e.detail.value;
        },
    weightinput(e){
            this.weight=e.detail.value;
        },
    showmessage(e){
        var p=new person(this.name,this.sex,this.birthplace,this.birthday,this.height,this.weight)
        this.setData({
            flag:false,
            person:p
        })
    }
})