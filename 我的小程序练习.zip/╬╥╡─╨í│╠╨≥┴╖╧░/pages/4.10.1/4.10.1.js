
Page({
    data: {
        array:['第一场15：00','第二场16：20','第三场17：40']
    },
    formsubmit(e){
        var name=e.detail.value.name;
        var id=e.detail.value.id;
        var time=e.detail.value.time;
        wx.showModal({
            title:'确认信息',
            content:e.detail.value.name+"同学，你的学号是："+id+"，你选择的场次是："+this.data.array[time]+",请确认你的信息！",
            success(res){
                if(res.confirm){
                    wx.showModal({
                      title:'信息确认',
                      content:'你的考试信息已确认！',
                    })
                    wx.navigateTo({
                      url: '../4.10/4.10',
                    })
                }
                else{
                    console.log('用户取消')
                }
            }
        })
    },
    choosetime(e){
        var index=e.detail.value;
        this.setData({
            index:index
        })
    }
    
})