var tempfilepaths,tempfilepath;
Page({
  data: {
   msg:'',
   hidden:true
  },
  openfile(){
    var that=this;
    wx.chooseImage({
      success(res){
        tempfilepaths=res.tempFilePaths,
        console.log('打开文件路径：'+tempfilepaths),
        that.setData({
          imagepath:tempfilepaths[0],
          hidden:false,
          msg:'文件打开成功！'
        })
      }
    })
  },
  savefile(){
    var that=this;
    wx.saveFile({
      tempFilePath:tempfilepaths[0],
      success(res){
console.log('保存文件路径'+res.savedFilePath);
that.setData({
  hidden:false,
  msg:'文件保存成功！'
})
      }
    })
  },
  getfile(){
    var that=this;
    var i,file;
    wx.getSavedFileList({
      success: (result) => {
        if(result.fileList.length==0){
          that.setData({
            hidden:false,
            msg:'没有文件信息'
          })
        }
        else{
          for(i=0;i<result.fileList.length;i++){
            file=result.fileList[i];
            console.log('第'+(i+1)+'个文件路径：'+result.filePath)
            wx.getSavedFileInfo({
              filePath: file.filePath,
              success(res){
                console.log('第'+i+'个文件大小为：'+res.size)
                that.setData({
                  hidden:false,
                  msg:'文件数量：'+i+'\n最后一个文件大小：'+res.size+'\n最后一个文件的创建时间:'+res.createTime
                })
              }
            })
          }
        }
      },
    })
  },
  removefile(){
    var i,file;
    var that=this;
    wx.getSavedFileList({
      success: (result) => {
        for(i=0;i<result.fileList.length;i++){
          file=result.fileList[i];
          wx.removeSavedFile({
            filePath: file.filePath,
          })
          console.log('第'+(i+1)+'个文件已删除！')
        }
        that.setData({
          hidden:false,
          msg:'文件被删除'
        })
      },
    })
  }
})
