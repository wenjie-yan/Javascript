Page({
    data: {
        getmail:'',
        pwd:'',
        confirm:''
    },
    formsubmit(e){
        if(e.detail.value.mail.length==0  ||  e.detail.value.passward.length==0){
            this.setData({
                showmsg01:'邮箱或密码不得为空！',
            })
        }
        else if(e.detail.value.passward != e.detail.value.confirm){
            this.setData({
                showmsg02:'两次密码输入不一致！',
                pwd:'',
                confirm:''
            })
        }
        else{
            wx.navigateTo({
                url:'/pages/4.10.1/4.10.1',
            })
        }
    },
    inputmail(e){
        var email=e.detail.value;
        var check=this.check(email);
    },
    check(e){
        let str=/^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/
        if(str.test(e)){
            return true;
        }
        else{
            wx.showToast({
              title: '邮箱格式错误',
              icon:'loading'
            })
            this.setData({
                getmail:''
            })
            return false;
        }
    }
})