Page({
  chooseimage(){
      var that=this;
      wx.chooseImage({
        count: 1,
        sizeType:['original','compressed'],
        sourceType:['album','camera'],
        success(res){
            that.setData({
                imagepath:res.tempFilePaths
            })
        }
      })
  },
  choosevideo(){
      var that=this;
      wx.chooseVideo({
        camera:'back',
        sourceType:['camera','album'],
        maxDuration:60,
        success(res){
            that.setData({
                videopath:res.tempFilePath
            })
        }
      })
  }

})