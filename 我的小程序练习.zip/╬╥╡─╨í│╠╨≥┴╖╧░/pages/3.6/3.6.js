Page({
    data: {
        cj:''
    },
jisuan:function(e){
var a=e.detail.value;
this.setData({
    cj:a
})
}
})