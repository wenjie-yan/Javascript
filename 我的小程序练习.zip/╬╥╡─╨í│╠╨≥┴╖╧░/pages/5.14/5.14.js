Page({
    startcompass(){
        var that=this;
        wx.startCompass({
          success(){
            wx.onCompassChange((result) => {
                that.setData({
                    resCompass:result
                })
            })
          }
        })
    },
    endcompass(){
        var that=this;
        wx.stopCompass({
          success: (res) => {},
        })
    },
    startacc(){
        var that=this;
        wx.startAccelerometer({
          success(){
            wx.onAccelerometerChange((result) => {
                that.setData({
                    resAcc:result
                })
            })
          }
        })
    },
    endacc(){
        var that=this;
        wx.stopAccelerometer({
          success: (res) => {},
        })
    },
    startgyroscope(){
        var that=this;
        wx.startGyroscope({
          success(){
            wx.onGyroscopeChange((result) => {
                that.setData({
                    resGyroscope:result
                })
            })
          }
        })
    },
    endgyroscope(){
        var that=this;
        wx.stopGyroscope({
          success: (res) => {
              console.log('已停止陀螺仪传感器监听')
          },
        })
    }
})