Page({

  
  data: {
    F1:0,
    G1:0
  },
  calc:function(e){
    var C ,F
     C=e.detail.value;
     F=C*9/5+32;
     this.setData({
       F1:F
     }) 
  },
  weight(a){
    var D, G
    D=a.detail.value;
    G=D*10;
    this.setData({
      G1:G
    })
  } 
})