
Page({


    data: {
        color:'blue',
        length:15
    },

    colorChange:function(e){
        var a=e.detail.value;
        this.setData({
            color:a
        })
    }
})