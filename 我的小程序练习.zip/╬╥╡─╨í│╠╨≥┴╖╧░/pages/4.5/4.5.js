// pages/4.5/4.5.js
Page({

    
    data: {
        background:['bcred','bcgreen','bcblue'],
        indicatordots:true,
        autoplay:false,
        circular:false,
        vertical:false,
        interval:2000,
        duration:500
    },
    changeindicatordots(e){
        this.setData({
            indicatordots:!this.data.indicatordots
        })
    },
    changeautoplay(e){
        this.setData({
            autoplay:!this.data.autoplay
        })
    },
    changecircular(e){
        this.setData({
            circular:!this.data.circular
        })
    },
    changevertical(e){
        this.setData({
            vertical:!this.data.vertical
        })
    },
})