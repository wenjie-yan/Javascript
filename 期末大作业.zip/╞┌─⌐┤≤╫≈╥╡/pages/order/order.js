
var m1=0,m2=0,m3=0;
Page({
  data: {
    m1: 0,
    m2: 0,
    m3: 0,
    num:0,
    Money:0
  },
  jiage: function (e) {

    this.setData({
      m1:m1,
      m2:m2,
      m3:m3,
      
    })

  },
  jia1: function (e) {
    m1++;
    this.setData({
      m1: m1
    })
  },
  jian1: function (e) {
    if (m1 > 0) {
      m1--;
      this.setData({
        m1: m1
      })
    } else {
      wx.showToast({
        icon: 'none',
        title: '数量不能小于0',
      })
    }
  },
  jia2: function (e) {
    m2++;
    this.setData({
      m2:m2
    })
  },
  jian2: function (e) {
    if (m2 > 0) {
      m2--;
      this.setData({
        m2: m2
      })
    } else {
      wx.showToast({
        icon: 'none',
        title: '数量不能小于0',
      })
    }
  },
  jia3: function (e) {
    m3++;
    this.setData({
      m3: m3
    })
  },
  jian3: function (e) {
    if (m3 > 0) {
      m3--;
      this.setData({
        m3: m3
      })
    } else {
      wx.showToast({
        icon: 'none',
        title: '数量不能小于0',
      })
    }
  },
  setStorage:function(){
    var that=this;
    if(m1>0){
      var flag1=false;
    }
    else{
      var flag1=true
    }
    if(m2>0){
      var flag2=false
    }
    else{
      var flag2=true
    }
    if(m3>0){
      var flag3=false
    }
    else{
      var flag3=true
    }
    wx.setStorageSync('a', [m1,flag1]);
    wx.setStorageSync('b', [m2,flag2]);
    wx.setStorageSync('c', [m3,flag3]);
  } 
})