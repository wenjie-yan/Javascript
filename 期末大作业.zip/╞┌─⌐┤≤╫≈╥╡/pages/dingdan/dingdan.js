var f=0;
Page({

    
    data: {
        msg01:'未登录，请您先登录!',
        f:0,
        arrayorder:[
            {
                name:'沙滩鲫鱼',
                accont:'0',
                cost:'0 dollar',
                flag:'true'
            },
            {
                name:'秘制狮子头',
                accont:'0',
                cost:'0 dollar',
                flag:'true'
            },
            {
                name:'排骨汤',
                accont:'0',
                cost:'0 dollar',
                flag:'true'
            }
        ]
    },
    onShow: function () {
        var name=wx.getStorageSync('用户名');
        if(name.length>0){
            f=1;
            this.setData({
                msg01:name
            })
        }
        else{
            f=0;
            this.setData({
                msg01:'未登录，请您先登录!'
            })
        }
    },
    cleanorder(){
        if(f==0){
            wx.showToast({
              title: '未登录！',
              icon:'error'
            })
        }
        else{
            this.setData({
                arrayorder:''
            })
            wx.removeStorageSync('a')
            wx.removeStorageSync('b')
            wx.removeStorageSync('c')
        }
        
    },
    checkorder(){
        if(f==0){
            wx.showToast({
              title: '未登录！',
              icon:'error'
            })
        }
        else{
        var a=wx.getStorageSync('a');  
        var b=wx.getStorageSync('b');
        var c=wx.getStorageSync('c');
        if(a!=0 || b!=0 || c!=0){
            this.setData({
                arrayorder:[
                    {
                        name:'沙滩鲫鱼',
                        accont:a[0],
                        cost:a[0]*6 +' dollar',
                        flag:a[1]
                    },
                    {
                        name:'秘制狮子头',
                        accont:b[0],
                        cost:b[0]*5 +' dollar',
                        flag:b[1]
                    },
                    {
                        name:'排骨汤',
                        accont:c[0],
                        cost:c[0]*5 +' dollar',
                        flag:c[1]
                    }
                ]
            })
        }
        
            
        }
    }
 
    
})