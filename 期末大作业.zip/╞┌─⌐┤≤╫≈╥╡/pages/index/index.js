Page({
  
  data: {
    imgSrc:'/images/1.jpg', 
    imgSrc1:'/images/2.jpg',
   
    autoplay: true,
    interval: 3000,
    duration: 1200
  },
  onLoad: function () {
    var that = this; 
    var data = {
      "datas": [
        {
          "id": 1,
          "imgurl": "../../images/meishi1.jpg"
        },
        {
          "id": 2,
          "imgurl": "../../images/meishi2.jpg"
        },
        {
          "id": 3,
          "imgurl": "../../images/meishi3.jpg"
        },
        {
          "id": 4,
          "imgurl": "../../images/meishi4.jpg"
        }
      ]
    }; 
    that.setData({
      lunboData: data.datas
    })
  },
  onShow(){
    wx.showToast({
      title: '欢迎点餐',
    })
  }
})