const app = getApp()

Page({//31.315864,121.393443
  data: {
    latitude:31.315864,
    longitude:121.393443,
    markers:[
      {//31.316688,121.392134
        id:1,
        latitude:31.316688,
        longitude:121.392134,
        iconPath:'/images/cat01.jpg',
        label:{
          content:'my location',
          color:'#0000FF',
          bgcolor:'#FFFF00',
          fontsize:'20'
        }
      },
    ]
  },
  chooseLocation:function(){
    wx.chooseLocation({
      success:function(res){
        console.log(res)
      },
    })
  },
  openLocation:function(){
    wx.getLocation({
      type:'gcj02',
      success:function(res){
        wx.openLocation({
          latitude: res.latitude,
          longitude: res.longitude,
          scale:18,
        })
      },
    })
  }
  
})
